#Note: be sure to set your working directory! Either through the GUI under the "More" menu in "Files", or with the command setwd.

#-----1.1-----
study1.data <- read.csv("Study1.csv")
str(study1.data) # See what type each variable is.
study1.data$Participant <- as.factor(study1.data$Participant) #Participant should be categorical, not an integer

#-----1.2 & 1.3-----
summary(study1.data$WPM)
#install.packages("psych")
library(psych)
describe(study1.data$WPM)
#install.packages("ggplot2")
library(ggplot2)
qplot(x=1, y=WPM, data=study1.data, geom="boxplot") + coord_flip() #boxplot expects 2 arguments by default, so we set y to be 1.
ggsave(file="study1_wpm_boxplot.png")
qplot(WPM, data=study1.data, geom="histogram")
ggsave(file="study1_wpm_histogram.png")

#-----1.4-----
qplot(x=Participant, y=WPM, data=study1.data, geom="boxplot")
ggsave(file="study1_wpmXparticipant_histogram.png")
#install.packages("lmerTest")
library(lmerTest)
study1.mixedmodel <- lmer(WPM ~ Method + (1 | Participant), data=study1.data)
#-----1.5-----
study1.mixedmodel
anova(study1.mixedmodel)
#install.packages("multcomp")
library(multcomp)
study1.tukey <- glht(study1.mixedmodel, linfct=mcp(Method = "Tukey"))
summary(study1.tukey)
